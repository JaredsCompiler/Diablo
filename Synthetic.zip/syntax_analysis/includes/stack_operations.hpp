double get_variable(std::map<std::string, double>, std::string);
void peetr();
